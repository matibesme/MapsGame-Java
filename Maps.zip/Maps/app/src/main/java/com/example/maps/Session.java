package com.example.maps;

import java.util.ArrayList;

public class Session {
    public static  ArrayList<Countries> countriesObtenidos = new ArrayList<Countries>();
    public static  Countries[] countriesRandom = {
            null,
            null,
            null,
            null

    };
    public static  ArrayList<Rankin> listaPersonas = new ArrayList<Rankin>();
    public static String nombre="";


}
