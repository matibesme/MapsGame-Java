package com.example.maps;

public class Response {
    public Countries [] response;
}
